package com.heliostorch.app

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.roundToInt

enum class TorchMode(val label: String) {
    STEADY("Steady"),
    STROBE("Strobe"),
    SOS("SOS"),
    PULSE("Pulse"),
    CANDLE("Candle"),
    BEACON("Beacon")
}

enum class SosSpeed(val label: String, val dotMs: Long, val pauseMs: Long) {
    STANDARD("Standard", 86L, 1200L),
    SLOW("Slow", 171L, 2200L)
}

private val MORSE_MAP = mapOf(
    'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
    'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
    'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
    'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
    'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
    'Z' to "--..", '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--",
    '4' to "....-", '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..",
    '9' to "----."
)

class MainActivity : ComponentActivity() {
    private lateinit var cameraManager: CameraManager
    private var torchCameraId: String? = null
    private var maxTorchLevel: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        discoverTorchCamera()

        setContent {
            HeliosTorchScreen(
                hasHardwareFlash = torchCameraId != null,
                supportsStrength = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxTorchLevel > 1,
                onSetHardwareTorch = { on, brightnessPct -> setHardwareTorch(on, brightnessPct) },
                onSetKeepScreenOn = { keepOn ->
                    if (keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            )
        }
    }

    override fun onDestroy() {
        setHardwareTorch(false, 0)
        super.onDestroy()
    }

    private fun discoverTorchCamera() {
        try {
            for (id in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    torchCameraId = id
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        maxTorchLevel = chars.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                    }
                    return
                }
            }
        } catch (e: Exception) {
            torchCameraId = null
        }
    }

    private fun setHardwareTorch(on: Boolean, brightnessPct: Int) {
        val id = torchCameraId ?: return
        try {
            if (!on || brightnessPct <= 0) {
                cameraManager.setTorchMode(id, false)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && maxTorchLevel > 1) {
                val level = ((brightnessPct / 100f) * maxTorchLevel).roundToInt().coerceIn(1, maxTorchLevel)
                cameraManager.turnOnTorchWithStrengthLevel(id, level)
            } else {
                cameraManager.setTorchMode(id, true)
            }
        } catch (e: Exception) {
            // Ignore hardware busy state
        }
    }
}

@Composable
fun HeliosTorchScreen(
    hasHardwareFlash: Boolean,
    supportsStrength: Boolean,
    onSetHardwareTorch: (Boolean, Int) -> Unit,
    onSetKeepScreenOn: (Boolean) -> Unit
) {
    var isOn by remember { mutableStateOf(false) }
    var brightness by remember { mutableIntStateOf(85) }
    var mode by remember { mutableStateOf(TorchMode.STEADY) }
    var strobeHz by remember { mutableIntStateOf(8) }
    var sosSpeed by remember { mutableStateOf(SosSpeed.STANDARD) }
    var morseText by remember { mutableStateOf("SOS") }
    var isMorseActive by remember { mutableStateOf(false) }
    var autoOffSec by remember { mutableStateOf<Int?>(null) }
    var screenLightFull by remember { mutableStateOf(false) }
    var wakeLockEnabled by remember { mutableStateOf(true) }
    var hapticsEnabled by remember { mutableStateOf(true) }
    val haptic = LocalHapticFeedback.current
    val triggerHaptic: () -> Unit = {
        if (hapticsEnabled) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    LaunchedEffect(wakeLockEnabled, isOn, isMorseActive) {
        onSetKeepScreenOn(wakeLockEnabled && (isOn || isMorseActive))
    }

    // Countdown auto-off timer
    LaunchedEffect(autoOffSec, isOn) {
        if (!isOn || autoOffSec == null) return@LaunchedEffect
        while (isActive && (autoOffSec ?: 0) > 0) {
            delay(1000L)
            autoOffSec = (autoOffSec ?: 1) - 1
        }
        if ((autoOffSec ?: 0) <= 0) {
            isOn = false
            autoOffSec = null
        }
    }

    // Main torch & Morse pattern driver
    LaunchedEffect(isOn, isMorseActive, mode, brightness, strobeHz, sosSpeed, morseText) {
        if (isMorseActive) {
            val cleaned = morseText.uppercase().trim()
            val dotMs = 100L
            while (isActive && isMorseActive && cleaned.isNotEmpty()) {
                for (ch in cleaned) {
                    if (!isActive || !isMorseActive) break
                    if (ch == ' ') {
                        onSetHardwareTorch(false, 0)
                        delay(dotMs * 7)
                        continue
                    }
                    val code = MORSE_MAP[ch] ?: continue
                    for ((idx, sym) in code.withIndex()) {
                        if (!isActive || !isMorseActive) break
                        onSetHardwareTorch(true, brightness)
                        delay(if (sym == '.') dotMs else dotMs * 3)
                        onSetHardwareTorch(false, 0)
                        if (idx < code.lastIndex) delay(dotMs)
                    }
                    delay(dotMs * 3)
                }
                delay(900L)
            }
            onSetHardwareTorch(false, 0)
            return@LaunchedEffect
        }

        if (!isOn) {
            onSetHardwareTorch(false, 0)
            return@LaunchedEffect
        }

        when (mode) {
            TorchMode.STEADY, TorchMode.PULSE, TorchMode.CANDLE -> {
                onSetHardwareTorch(true, brightness)
            }
            TorchMode.STROBE -> {
                val halfPeriod = (500L / strobeHz.coerceIn(1, 25)).coerceAtLeast(20L)
                while (isActive && isOn && mode == TorchMode.STROBE) {
                    onSetHardwareTorch(true, brightness)
                    delay(halfPeriod)
                    onSetHardwareTorch(false, 0)
                    delay(halfPeriod)
                }
            }
            TorchMode.SOS -> {
                val pattern = listOf(".", ".", ".", "-", "-", "-", ".", ".", ".")
                val d = sosSpeed.dotMs
                while (isActive && isOn && mode == TorchMode.SOS) {
                    for ((i, sym) in pattern.withIndex()) {
                        if (!isActive || !isOn) break
                        onSetHardwareTorch(true, brightness)
                        delay(if (sym == ".") d else d * 3)
                        onSetHardwareTorch(false, 0)
                        delay(if (i == 2 || i == 5) d * 3 else d)
                    }
                    delay(sosSpeed.pauseMs)
                }
            }
            TorchMode.BEACON -> {
                while (isActive && isOn && mode == TorchMode.BEACON) {
                    onSetHardwareTorch(true, brightness)
                    delay(260L)
                    onSetHardwareTorch(false, 0)
                    delay(1800L)
                }
            }
        }
    }

    if (screenLightFull) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White.copy(alpha = (brightness / 100f).coerceIn(0.1f, 1f)))
                .padding(24.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = {
                        triggerHaptic()
                        isOn = !isOn
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                ) {
                    Text(if (isOn) "Turn Off" else "Turn On", color = Color(0xFF0B0D12))
                }
                Button(
                    onClick = {
                        triggerHaptic()
                        screenLightFull = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B0D12))
                ) {
                    Text("Exit Screen Light", color = Color.White)
                }
            }
        }
        return
    }

    val bg = Color(0xFF0B0D12)
    val card = Color(0xFF131720)
    val border = Color(0xFF1E2533)
    val amber = Color(0xFFF59E0B)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Helios Torch", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (hasHardwareFlash) "Hardware LED Ready" else "Screen Light Ready",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            OutlinedButton(onClick = {
                triggerHaptic()
                screenLightFull = true
            }) {
                Text("Screen Light", color = amber)
            }
        }

        Button(
            onClick = {
                triggerHaptic()
                isMorseActive = false
                isOn = !isOn
            },
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isOn) amber else Color(0xFF1D2433),
                contentColor = if (isOn) Color(0xFF0B0D12) else Color.White
            )
        ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (isOn) "Turn Off Torch" else "Turn On Torch", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(card, RoundedCornerShape(16.dp))
                .border(1.dp, border, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                if (supportsStrength) "Brightness ($brightness%)" else "Screen Brightness ($brightness%)",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = brightness.toFloat(),
                onValueChange = { brightness = it.roundToInt().coerceIn(5, 100) },
                valueRange = 5f..100f
            )

            Text("Emitter Mode", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TorchMode.STEADY, TorchMode.STROBE, TorchMode.SOS).forEach { m ->
                    FilterChip(
                        selected = mode == m,
                        onClick = {
                            triggerHaptic()
                            mode = m
                        },
                        label = { Text(m.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TorchMode.PULSE, TorchMode.CANDLE, TorchMode.BEACON).forEach { m ->
                    FilterChip(
                        selected = mode == m,
                        onClick = {
                            triggerHaptic()
                            mode = m
                        },
                        label = { Text(m.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (mode == TorchMode.STROBE) {
                Text("Strobe Frequency: $strobeHz Hz", color = amber, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Slider(
                    value = strobeHz.toFloat(),
                    onValueChange = { strobeHz = it.roundToInt().coerceIn(1, 25) },
                    valueRange = 1f..25f
                )
            }

            Text("Emergency SOS Speed", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SosSpeed.entries.forEach { spd ->
                    FilterChip(
                        selected = sosSpeed == spd,
                        onClick = {
                            triggerHaptic()
                            sosSpeed = spd
                        },
                        label = { Text(spd.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(card, RoundedCornerShape(16.dp))
                .border(1.dp, border, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Morse Transmitter", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = morseText,
                onValueChange = { morseText = it },
                label = { Text("Signal Message") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    triggerHaptic()
                    isOn = false
                    isMorseActive = !isMorseActive
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (isMorseActive) Color(0xFFE11D48) else amber)
            ) {
                Icon(Icons.Default.FlashlightOn, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (isMorseActive) "Stop Morse Signal" else "Transmit Morse", color = Color(0xFF0B0D12))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (autoOffSec != null) "Auto-off in ${autoOffSec}s" else "Auto-off Timer",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(null to "Off", 30 to "30s", 300 to "5m").forEach { (sec, lbl) ->
                    OutlinedButton(onClick = { autoOffSec = sec }) {
                        Text(lbl, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
