# Helios Torch — Android Studio APK Project

This archive contains a complete, standalone Android Studio Gradle project (Kotlin + Jetpack Compose + Camera2 Flash API) for **Helios Torch**.

## Included Features
- Hardware Rear Camera LED Torch control (`CameraManager.setTorchMode` + Android 13+ `turnOnTorchWithStrengthLevel`)
- Steady, Strobe (1–25 Hz), Emergency SOS (with **Standard** and **Slow** pulsing speeds), Pulse, Candle, and Beacon modes
- Custom Morse Code optical transmitter
- Full-screen white Screen Light mode & Auto-Off timer
- Screen Wake Lock support

## How to Build the Installable APK
1. Extract `HeliosTorch-Android-APK.zip`.
2. Open the `HeliosTorch-Android` folder in **Android Studio** (Ladybug / Meerkat or newer).
3. Wait for Gradle Sync to download Android SDK dependencies.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Or from terminal inside `HeliosTorch-Android`: `./gradlew assembleDebug`
5. Locate the generated APK at:
   `app/build/outputs/apk/debug/app-debug.apk`
